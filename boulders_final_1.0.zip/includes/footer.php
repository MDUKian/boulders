<div <?php if($this_page=="index.php" ):?>id="hardfooter"
    <?php endif;?> class="footer-container">
        <footer class="wrapper">
            <section id="footaar">
                <h2>aarhus boulders</h2>
                <p>Åbent alle dage kl. 10-22</p>
                <p>Graham Bells Vej 18a,
                    <br> 8200 Aarhus C</p>
                <p>Email@aarhusboulders.dk
                    <br> +45 40 955 254
                    <br> CVR-nr.: 32777651</p>
                <div class="SoMecontainer">
                    <a href="<?php echo $aarfb ?>" target="_blank"><img class="SoMe" src="./media/img/facebook_ikon.png" alt=""></a>
                    <a href="<?php echo $aarinsta ?>" target="_blank"><img class="SoMe" src="./media/img/instagram_ikon.png" alt=""></a>
                    <a href="<?php echo $aarta ?>" target="_blank"><img class="SoMe" src="./media/img/tripadvisor_ikon.png" alt=""></a>
                </div>
            </section>
            <section id="footcph">
                <h2>copenhagen boulders</h2>
                <p>Åbent alle dage kl. 10-22</p>
                <p>Bådehavnsgade 38,
                    <br> 2450 København Sydhavn</p>
                <p>Email@copenhagenboulders.dk
                    <br> +45 70 255 254
                    <br> CVR-nr.: 32777651</p>
                <div class="SoMecontainer">
                    <a href="<?php echo $cphfb ?>" target="_blank"><img class="SoMe" src="./media/img/facebook_ikon.png" alt=""></a>
                    <a href="<?php echo $cphinsta ?>" target="_blank"><img class="SoMe" src="./media/img/instagram_ikon.png" alt=""></a>
                    <a href="<?php echo $cphta ?>" target="_blank"><img class="SoMe" src="./media/img/tripadvisor_ikon.png" alt=""></a>
                </div>
            </section>
        </footer>
</div>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>
    window.jQuery || document.write('<script src="js/vendor/jquery-1.11.2.min.js"><\/script>')
</script>

<script src="js/main.js"></script>
</body>

</html>