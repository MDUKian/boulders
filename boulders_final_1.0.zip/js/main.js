

$(function() {
    $('.nav-btn').on('click', function(){
		$('body').toggleClass('nav-opened');
		$('.logosmall').toggle();
	});
});



